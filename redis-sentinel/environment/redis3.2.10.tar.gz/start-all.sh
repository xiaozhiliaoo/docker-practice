#!/bin/sh
# start all redis serice
# start master

redis-server redis-master.conf

# start slave

redis-server redis-slave.conf

# start sentinal

redis-sentinel redis-sentinel.conf
