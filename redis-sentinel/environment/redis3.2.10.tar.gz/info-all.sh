#!/bin/sh
# all redis serice info

# info master
echo "#### master info ####"
PID=`ps aux | grep redis-server | grep -v grep | grep 6379 | awk '{printf $2}'`
if [ "" != "$PID" ]
then
	redis-cli -p 6379 -a mx2017 info replication
else
	echo redis master not run
fi

# info slave
echo "#### slave info ####"
PID=`ps aux | grep redis-server | grep -v grep | grep 6378 | awk '{printf $2}'`
if [ "" != "$PID" ]
then
	redis-cli -p 6378 -a mx2017 info replication
else
        echo redis slave not run
fi

# info sentinel
echo "#### sentinel info ####"
PID=`ps aux | grep redis-sentinel | grep -v grep | awk '{printf $2}'`
if [ "" != "$PID" ]
then
	redis-cli -p 26379 -a mx2017 info sentinel
else
        echo redis sentinel not run
fi

