#!/bin/sh
# stop all redis serice
# stop master

PID=`ps aux | grep redis-server | grep -v grep | grep 6379 | awk '{printf $2}'`
if [ "" != "$PID" ]
then
	kill -9 $PID
	echo "kill reids master   pid = $PID"
else
	echo redis master not run
fi

# stop slave
PID=`ps aux | grep redis-server | grep -v grep | grep 6378 | awk '{printf $2}'`
if [ "" != "$PID" ]
then
        kill -9 $PID
        echo "kill reids slave    pid = $PID"
else
        echo redis slave not run
fi

# stop sentinal
PID=`ps aux | grep redis-sentinel | grep -v grep | awk '{printf $2}'`
if [ "" != "$PID" ]
then
        kill -9 $PID
        echo "kill redis sentinel pid = $PID"
else
        echo redis sentinel not run
fi

