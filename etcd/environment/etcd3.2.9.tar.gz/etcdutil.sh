#!/usr/bin/env bash
#集群常量配置
#集群通信token，全局唯一
curr_dir=$(pwd)    #当前目录下建立数据文件和日志文件 data  log
export ETCDCTL_API=3
DATA_DIR_ROOT=$curr_dir/data
LOG_FILE=$curr_dir/log
DATA_DIR1=$curr_dir/data/etcd1
DATA_DIR2=$curr_dir/data/etcd2
DATA_DIR3=$curr_dir/data/etcd3
CLUSTER_TOKEN=etcd-cluster
NODE_NAME1=etcd1
NODE_NAME2=etcd2
NODE_NAME3=etcd3
#节点和集群间的ip和端口
ETCD1_IP=http://localhost
ETCD2_IP=http://localhost
ETCD3_IP=http://localhost
ETCD1_PEER_PORT=2380
ETCD2_PEER_PORT=22380
ETCD3_PEER_PORT=32380
ETCD1_CLIENT_PORT=2379
ETCD2_CLIENT_PORT=22379
ETCD3_CLIENT_PORT=32379
CLUSTER=etcd1=${ETCD1_IP}:${ETCD1_PEER_PORT},etcd2=${ETCD2_IP}:${ETCD2_PEER_PORT},etcd3=${ETCD3_IP}:${ETCD3_PEER_PORT}
ENDPOINTS=${ETCD1_IP}:${ETCD1_CLIENT_PORT},${ETCD2_IP}:${ETCD2_CLIENT_PORT},${ETCD3_IP}:${ETCD3_CLIENT_PORT}

usage(){
    echo "usage:"
    echo $0" new    | create and run new etcd cluster"
    echo $0" start  | when etcd cluster is not running, start the cluster"
    echo $0" stop   | stop the etcd cluster"
    echo $0" destroy| destroy the the etcd cluster， be careful！！！"
    echo $0" status | for command: etcdctl --write-out=table --endpoints=${ENDPOINTS} endpoint status"
    echo $0" member | for command: etcdctl --write-out=table --endpoints=${ENDPOINTS} member list"
    echo $0" health | for command: etcdctl --write-out=table --endpoints=${ENDPOINTS}  endpoint health"
}

#创建集群
new(){

        echo "Starting create the etcd cluster"

        # 先判断data目录是否存在，如果存在将不能运行，防止把当前运行的集群信息给覆盖了
        if [ -e ${DATA_DIR_ROOT} ]; then
                echo "New etcd cluster fail. because etcd data dir exist, can't new and run a new etcd cluster."
                return 1
        fi

        curr_dir=$(pwd)
        `mkdir -p log`
        `mkdir -p data/etcd1`
        `mkdir -p data/etcd2`
        `mkdir -p data/etcd3`

        DATA_DIR1=$curr_dir/data/etcd1
        DATA_DIR2=$curr_dir/data/etcd2
        DATA_DIR3=$curr_dir/data/etcd3

        etcd    --name ${NODE_NAME1} \
                --data-dir=${DATA_DIR1} \
                --initial-advertise-peer-urls ${ETCD1_IP}:${ETCD1_PEER_PORT} \
                --listen-peer-urls ${ETCD1_IP}:${ETCD1_PEER_PORT} \
                --advertise-client-urls ${ETCD1_IP}:${ETCD1_CLIENT_PORT} \
                --listen-client-urls ${ETCD1_IP}:${ETCD1_CLIENT_PORT} \
                --initial-cluster ${CLUSTER}  \
                --initial-cluster-token ${CLUSTER_TOKEN} \
                --initial-cluster-state new  >> ${LOG_FILE}/etcd1.log 2>&1 &

        sleep 1s

        echo "create etcd member,ip=${ETCD1_IP}:${ETCD1_CLIENT_PORT},name=${NODE_NAME1}"

        etcd    --name ${NODE_NAME2} \
                --data-dir=${DATA_DIR2} \
                --initial-advertise-peer-urls ${ETCD2_IP}:${ETCD2_PEER_PORT} \
                --listen-peer-urls ${ETCD2_IP}:${ETCD2_PEER_PORT} \
                --advertise-client-urls ${ETCD2_IP}:${ETCD2_CLIENT_PORT} \
                --listen-client-urls ${ETCD2_IP}:${ETCD2_CLIENT_PORT} \
                --initial-cluster ${CLUSTER}  \
                --initial-cluster-token ${CLUSTER_TOKEN} \
                --initial-cluster-state new  >> ${LOG_FILE}/etcd2.log 2>&1 &

        sleep 1s

        echo "create etcd member,ip=${ETCD2_IP}:${ETCD2_CLIENT_PORT},name=${NODE_NAME2}"

        etcd    --name ${NODE_NAME3} \
                --data-dir=${DATA_DIR3} \
                --initial-advertise-peer-urls ${ETCD3_IP}:${ETCD3_PEER_PORT} \
                --listen-peer-urls ${ETCD3_IP}:${ETCD3_PEER_PORT} \
                --advertise-client-urls ${ETCD3_IP}:${ETCD3_CLIENT_PORT} \
                --listen-client-urls ${ETCD3_IP}:${ETCD3_CLIENT_PORT} \
                --initial-cluster ${CLUSTER}  \
                --initial-cluster-token ${CLUSTER_TOKEN} \
                --initial-cluster-state new  >> ${LOG_FILE}/etcd3.log 2>&1 &

        echo "create etcd member,ip=${ETCD3_IP}:${ETCD3_CLIENT_PORT},name=${NODE_NAME3}"
        if [ $? -ne 0 ]; then
        return 1
        fi
        return 0
}

#开启集群
start(){
        # 不存在数据目录
        if [ ! -e ${DATA_DIR_ROOT} ]; then
                echo "No etcd cluster exist, please new one"
                return 1
        fi

        ID=`ps -ef|grep "etcd[1,2,3]" | grep -v "grep" | awk '{print $2}'`

        if [ "" = "$ID" ]; then
                echo "start etcd cluster, please wait..."
        else
                echo "etcd cluster is running now"
                return 1
        fi

        etcd    --name ${NODE_NAME1} \
                --data-dir=${DATA_DIR1} \
                --initial-advertise-peer-urls ${ETCD1_IP}:${ETCD1_PEER_PORT} \
                --listen-peer-urls ${ETCD1_IP}:${ETCD1_PEER_PORT} \
                --advertise-client-urls ${ETCD1_IP}:${ETCD1_CLIENT_PORT} \
                --listen-client-urls ${ETCD1_IP}:${ETCD1_CLIENT_PORT} \
                --initial-cluster ${CLUSTER}  \
                --initial-cluster-token ${CLUSTER_TOKEN} \
                --initial-cluster-state existing  >> ${LOG_FILE}/etcd1.log 2>&1 &
        sleep 1
        echo "start etcd member,ip=${ETCD1_IP}:${ETCD1_CLIENT_PORT},name=${NODE_NAME1}"

        etcd    --name ${NODE_NAME2} \
                --data-dir=${DATA_DIR2} \
                --initial-advertise-peer-urls ${ETCD2_IP}:${ETCD2_PEER_PORT} \
                --listen-peer-urls ${ETCD2_IP}:${ETCD2_PEER_PORT} \
                --advertise-client-urls ${ETCD2_IP}:${ETCD2_CLIENT_PORT} \
                --listen-client-urls ${ETCD2_IP}:${ETCD2_CLIENT_PORT} \
                --initial-cluster ${CLUSTER}  \
                --initial-cluster-token ${CLUSTER_TOKEN} \
                --initial-cluster-state existing  >> ${LOG_FILE}/etcd2.log 2>&1 &
        sleep 1
        echo "start etcd member,ip=${ETCD2_IP}:${ETCD2_CLIENT_PORT},name=${NODE_NAME2}"

        etcd    --name ${NODE_NAME3} \
                --data-dir=${DATA_DIR3} \
                --initial-advertise-peer-urls ${ETCD3_IP}:${ETCD3_PEER_PORT} \
                --listen-peer-urls ${ETCD3_IP}:${ETCD3_PEER_PORT} \
                --advertise-client-urls ${ETCD3_IP}:${ETCD3_CLIENT_PORT} \
                --listen-client-urls ${ETCD3_IP}:${ETCD3_CLIENT_PORT} \
                --initial-cluster ${CLUSTER}  \
                --initial-cluster-token ${CLUSTER_TOKEN} \
                --initial-cluster-state existing  >> ${LOG_FILE}/etcd3.log 2>&1 &
        sleep 1
        echo "start etcd member,ip=${ETCD3_IP}:${ETCD3_CLIENT_PORT},name=${NODE_NAME3}"

        if [ $? -ne 0 ]; then
        return 1
        fi
        return 0
}


#关闭集群
stop(){
	 #kill -9 `pgrep etcd -x`   # 关闭不了看日志的进程
	 #关闭和etcd相关的进程
	 kill -9 `ps -ef|grep "etcd[1,2,3]"| grep -v "grep" | awk '{print $2}'`
}


#集群成员信息
memberlist(){
	etcdctl --endpoints=${ENDPOINTS} --write-out=table member list
	if [ $? -ne 0 ]; then
        return 1
    fi
    return 0
}

#集群状态
endpointstatus(){
    etcdctl --endpoints=${ENDPOINTS} --write-out=table endpoint status
    if [ $? -ne 0 ]; then
        return 1
    fi
        return 0
}

#彻底删除集群，清空数据和日志
destroy(){

    ID=`ps -ef|grep "etcd[1,2,3]" | grep -v "grep" | awk '{print $2}'`

    if [ "" = "$ID" ]; then
        clear
    else
        echo "stop the etcd process"
        kill -9 ${ID}
        clear
    fi

    echo "destroy the the etcd cluster successful"
}

clear(){
    rm -rf ${DATA_DIR_ROOT}
    rm -rf ${LOG_FILE}
}

#重新启动
#restart(){
#    stop
#    sleep 1s
#    start
#    if [ $? -ne 0 ]; then
#        return 1
#    fi
#        return 0
#}

#节点健康状况
health(){
    etcdctl --endpoints=${ENDPOINTS} --write-out=table endpoint health
    if [ $? -ne 0 ]; then
        return 1
    fi
        return 0
}

#unuse
#生成快照
#snapshot(){
#	mkdir -p ${DATA_DIR_ROOT}/snapshot
#	ts=` date "+%Y-%m-%d_%H:%M:%S"`
#	etcdctl snapshot save ${DATA_DIR_ROOT}/snapshot/${ts}.db
#}


#unuse
#add(){
#
#	etcdctl --endpoints=${ENDPOINTS} member add ${THIS_NAME} --peer-urls=${THIS_IP}:2380
#
#	if [ $? -ne 0 ]; then
#        return 1
#    fi
#	nohup etcd --data-dir=${DATA_DIR} \
#	           --name ${THIS_NAME} \
#	           --initial-advertise-peer-urls ${THIS_IP}:2380 \
#	           --listen-peer-urls ${THIS_IP}:2380 \
#	           --listen-client-urls ${THIS_IP}:2379 \
#               --advertise-client-urls ${THIS_IP}:2379 \
#               --initial-cluster-token ${TOKEN}	 \
#               --auto-compaction-retention=1 \
#	           --initial-cluster ${CLUSTER} --initial-cluster-state existing  > ${LOG_FILE} 2>&1 &
#
#	if [ $? -ne 0 ]; then
#        return 1
#    fi
#    return 0
#}


result=0
if [ "$1" == "new" ]; then
        new
        result=$?
elif [ "$1" == "start" ]; then
        start
        result=$?
elif [ "$1" == "stop" ]; then
        stop
        result=$?
elif [ "$1" == "destroy" ]; then
        destroy
elif [ "$1" == "health" ]; then
        health
        result=$?
elif [ "$1" == "status" ]; then
        endpointstatus
        result=$?
elif [ "$1" == "member" ]; then
        memberlist
        result=$?
else
        usage
fi

# 1失败 0 成功
if [ $result -ne 0 ]; then
        echo "fail ... "
else
        echo "success ..."
fi

exit $result


